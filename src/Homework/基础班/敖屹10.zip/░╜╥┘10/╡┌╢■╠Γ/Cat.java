package homework.敖屹10.第二题;

public class Cat implements Animal {

    @Override
    public void eat() {
        System.out.println("猫吃鱼");

    }
}
