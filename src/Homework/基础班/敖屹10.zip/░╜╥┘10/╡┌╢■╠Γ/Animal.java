package homework.敖屹10.第二题;

public interface Animal {
    void eat();
}
