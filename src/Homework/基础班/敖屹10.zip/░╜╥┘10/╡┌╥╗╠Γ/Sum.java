package homework.敖屹10.第一题;

public interface Sum {
    int sum();
}
