package homework.敖屹10.第三题;

import java.lang.reflect.Array;

public interface Max {
    int[] setArr();

    void maxNum(int[] arr);
}
