package homework.敖屹10.第四题;

public interface Drink extends Behaviour {
    String drink();
}
