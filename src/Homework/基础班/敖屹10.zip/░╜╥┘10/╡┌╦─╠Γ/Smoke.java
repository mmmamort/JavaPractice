package homework.敖屹10.第四题;

public interface Smoke extends Behaviour {
    String smoke();
}
