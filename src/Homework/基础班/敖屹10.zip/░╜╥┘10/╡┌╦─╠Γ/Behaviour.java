package homework.敖屹10.第四题;

public interface Behaviour {
    void behaviour();

    void action();
}
