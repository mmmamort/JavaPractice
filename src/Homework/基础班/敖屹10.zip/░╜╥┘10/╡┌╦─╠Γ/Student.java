package homework.敖屹10.第四题;

public class Student extends Person implements Smoke, Drink {
    public Student(String name, int age) {
        super(name, age);
    }

    public Student() {
    }

    @Override
    public void action() {
        System.out.println(super.getName() + "正在学习");
    }

    @Override
    public void eat() {
        System.out.println(super.getName() + "吃果果");
    }

    @Override
    public void sleep() {
        System.out.println(super.getName() + "24点睡觉");
    }

    @Override
    public void behaviour() {
        System.out.println("学生" + super.getName() + smoke() + drink());

    }

    @Override
    public String drink() {
        return "会喝酒";
    }

    @Override
    public String smoke() {
        return "会抽烟";
    }
}
