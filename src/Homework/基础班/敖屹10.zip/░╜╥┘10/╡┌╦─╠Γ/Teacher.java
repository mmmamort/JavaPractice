package homework.敖屹10.第四题;

public class Teacher extends Person implements Smoke {
    public Teacher(String name, int age) {
        super(name, age);
    }

    public Teacher() {
    }

    @Override
    public void action() {
        System.out.println(super.getName() + "正在上课");
    }

    @Override
    public void eat() {
        System.out.println(super.getName() + "吃大果果");
    }

    @Override
    public void sleep() {
        System.out.println(super.getName() + "23点睡觉");
    }

    @Override
    public void behaviour() {
        System.out.println("老师" + super.getName() + smoke());
    }

    @Override
    public String smoke() {
        return "会吸烟";
    }
}
