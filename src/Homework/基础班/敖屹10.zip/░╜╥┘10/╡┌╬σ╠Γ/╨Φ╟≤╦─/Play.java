package homework.敖屹10.第五题.需求四;

public interface Play {
    void playGame();
}
