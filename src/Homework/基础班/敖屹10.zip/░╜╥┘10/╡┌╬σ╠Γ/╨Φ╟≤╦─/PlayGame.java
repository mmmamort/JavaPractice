package homework.敖屹10.第五题.需求四;

public class PlayGame implements Play {
    @Override
    public void playGame() {
        System.out.println("使用实现类，来调用");
    }
}
