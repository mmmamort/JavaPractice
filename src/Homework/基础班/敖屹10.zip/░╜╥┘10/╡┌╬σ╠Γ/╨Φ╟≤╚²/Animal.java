package homework.敖屹10.第五题.需求三;

import java.sql.SQLOutput;

public class Animal {
    private String color;
    private int legNum;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getLegNum() {
        return legNum;
    }

    public void setLegNum(int legNum) {
        this.legNum = legNum;
    }

    public Animal(String color, int legNum) {

        this.color = color;
        this.legNum = legNum;
    }

    public Animal() {

    }

    public void information() {
        System.out.println("是" + color + "的，有" + legNum + "条腿。");
    }
}
