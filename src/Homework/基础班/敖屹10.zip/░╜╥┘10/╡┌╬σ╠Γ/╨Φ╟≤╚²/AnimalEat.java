package homework.敖屹10.第五题.需求三;

public interface AnimalEat {
    void eat();

    void information();
}
