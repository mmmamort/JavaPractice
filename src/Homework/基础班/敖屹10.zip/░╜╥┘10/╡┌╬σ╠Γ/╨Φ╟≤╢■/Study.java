package homework.敖屹10.第五题.需求二;

public interface Study {
    void study();
}
