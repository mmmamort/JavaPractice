package homework.敖屹10.第五题.需求一;

public interface Teach {
    void teach();
}
