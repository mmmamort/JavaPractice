package homework.敖屹10.第五题.需求五;

public class Dog2 extends Animal2 implements Jump {
    public Dog2(String name, int age) {
        super(name, age);
    }

    public Dog2() {
    }

    @Override
    public void eat() {
        System.out.println(super.getName() + "吃肉");
    }

    @Override
    public void sleep() {
        System.out.println(super.getName() + "23点睡觉");
    }

    @Override
    public void imformation() {
        System.out.println("狗叫" + super.getName() + jump());
    }

    @Override
    public String jump() {
        return "会跳高";
    }
}
