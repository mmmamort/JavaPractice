package homework.敖屹10.第五题.需求五;

public class Cat2 extends Animal2 implements Jump {
    public Cat2(String name, int age) {
        super(name, age);
    }

    public Cat2() {
    }

    @Override
    public void eat() {
        System.out.println(super.getName() + "吃鱼");
    }

    @Override
    public void sleep() {
        System.out.println(super.getName() + "24点睡觉");
    }

    @Override
    public void imformation() {
        System.out.println("猫叫" + super.getName() + jump());

    }

    @Override
    public String jump() {
        return "会跳高";
    }

}
