package homework.敖屹10.第五题.需求五;

public interface Jump {
    void eat();

    void sleep();

    void imformation();

    String jump();
}
