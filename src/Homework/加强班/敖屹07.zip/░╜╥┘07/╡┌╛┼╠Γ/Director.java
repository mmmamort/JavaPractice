package Homework.加强班.敖屹07.第九题;

public interface Director {
    void makeMovie();
}
