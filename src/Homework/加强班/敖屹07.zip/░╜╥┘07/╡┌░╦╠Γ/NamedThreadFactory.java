package Homework.加强班.敖屹07.第八题;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public class NamedThreadFactory implements ThreadFactory {
    private AtomicInteger tag = new AtomicInteger(0);
    private String[] name = {"王老师", "李老师"};

    @Override
    public Thread newThread(Runnable r) {
        Thread thread = new Thread(r);
        thread.setName(name[tag.getAndIncrement()]);
        return thread;
    }
}
