package Homework.加强班.敖屹07.第十题;

public interface Calculator {
    int calc(int a, int b);
}
