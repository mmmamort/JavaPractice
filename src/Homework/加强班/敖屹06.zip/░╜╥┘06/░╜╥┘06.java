package Homework.加强班.敖屹06;

public class 敖屹06 {
    public static void main(String[] args) {
        System.out.println("第一题");
        {
            System.out.println("run()方法中写入子线程要执行的语句，用start()方法在main方法中调用该线程，并执行其中的语句。");
        }

        System.out.println("\n第二题");
        {
            System.out.println("通过创建Thread子类对象，并调用其中start()方法来开启子线程");
            System.out.println("通过创建Runnable实现类对象，并通过创建Thread对象调用其中start()方法来开启子线程");
        }

        System.out.println("第三题\n在包“第三题”中");

        System.out.println("\n第四题");
        {
            System.out.println("适合多个线程共享同一个实现类中的资源\n实现类中代码可以被多个线程共享\n可以加入线程池\n可以实现多继承");
        }

        System.out.println("\n第五题");
        {
            System.out.println("新建，可运行，无线等待，计时等待，锁阻塞，被终止。");
        }

        System.out.println("第六题\n在包“第六题”中");

        System.out.println("第七题\n在包“第七题”中");

        System.out.println("第八题\n在包“第八题”中");

        System.out.println("第九题\n在包“第九题”中");
    }
}
