package Homework.加强班.敖屹06.第八题;

public class 第八题 {
    public static void main(String[] args) {
        System.out.println("\n第八题");
        {
            Test test = new Test();
            test.test();
        }
    }
}
