package Homework.加强班.敖屹06.第八题;

public class Test {
    public static void test() {
        Thread01 thread01 = new Thread01();
        Thread02 thread02 = new Thread02();
        thread01.start();
        thread02.start();
    }
}
