package Homework.加强班.敖屹05.第十题;

public class BloodNumberOutOfBoundsExcepution extends RuntimeException {
    public BloodNumberOutOfBoundsExcepution() {
    }

    public BloodNumberOutOfBoundsExcepution(String message) {
        super(message);
    }
}
